import 'package:whisper_ggml/whisper_ggml.dart';
import 'whisper_engine_types.dart';

export 'whisper_engine_types.dart';

final WhisperController _controller = WhisperController();

WhisperModel _modelFor(String key) =>
    key == 'base' ? WhisperModel.base : WhisperModel.small;

Future<EngineResult> whisperTranscribe({
  required String path,
  required String lang,
  required String model,
}) async {
  final result = await _controller.transcribe(
    model: _modelFor(model),
    audioPath: path,
    lang: lang,
  );
  final whole = result?.transcription.text.trim() ?? '';
  return EngineResult(_segments(result), whole);
}

/// Paket parça bazlı zaman damgası veriyorsa kullanır. Alan adları doğrulanmadığı için
/// dinamik okunur; beklenmedik bir şey olursa boş döner.
List<EngineSegment> _segments(dynamic result) {
  try {
    final dynamic segs = result?.transcription?.segments;
    if (segs is! List || segs.isEmpty) return const [];
    final out = <EngineSegment>[];
    for (final dynamic s in segs) {
      final dynamic from = s.fromTs;
      final dynamic text = s.text;
      if (from is! Duration || text is! String) return const [];
      final t = text.trim();
      if (t.isEmpty) continue;
      out.add(EngineSegment(from.inMilliseconds, t));
    }
    return out;
  } catch (_) {
    return const [];
  }
}
