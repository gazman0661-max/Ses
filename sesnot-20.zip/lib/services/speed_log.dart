import 'dart:convert';
import 'settings_store.dart';
import 'whisper_service.dart';

/// Son çeviri işlerinin hız ölçümleri (model karşılaştırması için).
class SpeedLog {
  static const _key = 'speedLog';

  static Future<List<Map<String, dynamic>>> load() async {
    try {
      final raw = await SettingsStore.getString(_key, '[]');
      return List<Map<String, dynamic>>.from(jsonDecode(raw) as List);
    } catch (_) {
      return [];
    }
  }

  static Future<void> add({
    required String model,
    required String lang,
    required bool live,
    required RunStats stats,
    required int waitSeconds,
  }) async {
    final entries = await load();
    final worked = stats.chunks.where((c) => !c.skipped).toList();
    entries.insert(0, {
      't': DateTime.now().toIso8601String(),
      'model': model,
      'lang': lang,
      'live': live,
      'audioSec': stats.audioMs ~/ 1000,
      'waitSec': waitSeconds,
      'chunks': stats.chunks.length,
      'skipped': stats.skipped,
      'first': [
        for (final c in worked.take(6)) [c.audioMs ~/ 1000, c.tookMs ~/ 1000]
      ],
    });
    if (entries.length > 10) entries.removeRange(10, entries.length);
    await SettingsStore.setString(_key, jsonEncode(entries));
  }

  static Future<void> clear() => SettingsStore.setString(_key, '[]');

  static String describe(Map<String, dynamic> e) {
    String two(int n) => n.toString().padLeft(2, '0');
    String mmss(int s) => formatStamp(s * 1000);
    final audio = (e['audioSec'] as num?)?.toInt() ?? 0;
    final wait = (e['waitSec'] as num?)?.toInt() ?? 0;
    final live = e['live'] == true;
    final ratio = audio > 0 ? (wait / audio).toStringAsFixed(2) : '-';
    final t = DateTime.tryParse((e['t'] as String?) ?? '');
    final when = t == null
        ? ''
        : '${two(t.day)}.${two(t.month)} ${two(t.hour)}:${two(t.minute)} · ';
    final first = ((e['first'] as List?) ?? []).map((p) {
      final l = p as List;
      return '${l[0]}s→${l[1]}s';
    }).join(', ');
    return '$when${e['model']} · ${e['lang']}${live ? ' · kayıt sırasında yazıya dökmeli' : ''}\n'
        'Ses ${mmss(audio)} · ${live ? 'bitişten sonra bekleme' : 'toplam süre'} ${mmss(wait)}'
        '${live ? '' : ' ($ratio kat)'}\n'
        'Sessiz atlanan parça: ${e['skipped']}/${e['chunks']}\n'
        'İlk parçalar (ses→süre): ${first.isEmpty ? '-' : first}';
  }
}
