import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';

/// Android'in "Farklı kaydet" ekranını açar: kullanıcı klasörü seçer,
/// dosya adını istediği gibi yazar. Ekstra izin gerekmez.
class FileSaveService {
  /// Dosya adında sorun çıkaran karakterleri temizler.
  static String safeName(String s, {String fallback = 'Not'}) {
    final cleaned = s
        .replaceAll(RegExp(r'[\\/:*?"<>|\n\r\t]'), ' ')
        .trim()
        .replaceAll(RegExp(r'\s+'), '_');
    if (cleaned.isEmpty) return fallback;
    return cleaned.length > 60 ? cleaned.substring(0, 60) : cleaned;
  }

  /// Kaydedilen yolu döndürür. Kullanıcı vazgeçerse null.
  static Future<String?> save({
    required Uint8List bytes,
    required String fileName,
    required String ext,
  }) {
    return FilePicker.platform.saveFile(
      dialogTitle: 'Nereye kaydedilsin?',
      fileName: '$fileName.$ext',
      bytes: bytes,
      type: FileType.custom,
      allowedExtensions: [ext],
    );
  }
}
