import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/project.dart';
import 'file_save_service.dart';
import 'pdf_service.dart';
import 'project_store.dart';

enum ExportFormat { pdf, txt }

/// Bütün notları herkesin açabileceği bir dosyaya (PDF veya metin) çevirir.
class NotesExportService {
  static String _two(int n) => n.toString().padLeft(2, '0');
  static String _date(DateTime d) => '${_two(d.day)}.${_two(d.month)}.${d.year}';
  static String _dateTime(DateTime d) => '${_date(d)} ${_two(d.hour)}:${_two(d.minute)}';

  static String buildText(List<Project> notes) {
    final b = StringBuffer()
      ..writeln('SesNot notları')
      ..writeln('${_date(DateTime.now())} tarihinde dışa aktarıldı · ${notes.length} not');
    for (final p in notes) {
      b
        ..writeln()
        ..writeln('==============================')
        ..writeln(p.title)
        ..writeln(_dateTime(p.updatedAt))
        ..writeln('------------------------------')
        ..writeln(p.body.trim());
    }
    return b.toString();
  }

  /// Not yoksa null, kullanıcı kaydetmekten vazgeçtiyse false, aksi halde true.
  /// share=true paylaşım menüsünü, false "Farklı kaydet" ekranını açar.
  static Future<bool?> run({required ExportFormat format, required bool share}) async {
    final notes = await ProjectStore.list();
    if (notes.isEmpty) return null;

    final now = DateTime.now();
    final name = 'sesnot_notlar_${now.year}${_two(now.month)}${_two(now.day)}';
    final ext = format == ExportFormat.pdf ? 'pdf' : 'txt';
    final Uint8List bytes = format == ExportFormat.pdf
        ? await PdfService.notesPdfBytes(notes)
        : Uint8List.fromList(utf8.encode(buildText(notes)));

    if (share) {
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/$name.$ext');
      await file.writeAsBytes(bytes, flush: true);
      await Share.shareXFiles([XFile(file.path)]);
      return true;
    }
    final path = await FileSaveService.save(bytes: bytes, fileName: name, ext: ext);
    return path != null;
  }
}
