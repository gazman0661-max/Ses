import 'package:flutter/services.dart';

/// Android tarafıyla köprü (tools/android/AudioBridge.kt.tpl, CI'da eklenir):
/// 1) Başka uygulamadan "Paylaş → SesNot" ile gelen ses (WhatsApp sesli mesajı vb.)
/// 2) Her biçimdeki sesi Whisper'ın istediği 16 kHz mono WAV'a çevirme.
/// Android dışında kanal olmadığından çağrılar sessizce null döner.
class SharedAudio {
  static const _ch = MethodChannel('sesnot/share');
  static void Function(String path)? _onShared;
  static void Function(String message)? _onError;

  /// Uygulama açıkken gelen yeni paylaşımları dinler.
  static void listen({
    required void Function(String path) onShared,
    void Function(String message)? onError,
  }) {
    _onShared = onShared;
    _onError = onError;
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'shared') {
        final p = call.arguments as String?;
        if (p != null) _onShared?.call(p);
      } else if (call.method == 'shareError') {
        _onError?.call(call.arguments?.toString() ?? 'Ses alınamadı');
      }
    });
  }

  static void stopListening() {
    _onShared = null;
    _onError = null;
  }

  /// Uygulama paylaşımla açıldıysa kopyalanan ses dosyasının yolu, yoksa null.
  static Future<String?> initial() async {
    try {
      return await _ch.invokeMethod<String>('getInitialShare');
    } on MissingPluginException {
      return null;
    } on PlatformException catch (e) {
      throw Exception(e.message ?? 'Ses alınamadı');
    }
  }

  /// Dosyayı 16 kHz mono WAV'a çevirip yeni yolu döner. Android dışında null.
  /// Biçim çözülemezse Exception fırlatır.
  static Future<String?> toWav(String path) async {
    try {
      return await _ch.invokeMethod<String>('convertToWav', {'path': path});
    } on MissingPluginException {
      return null;
    } on PlatformException catch (e) {
      throw Exception(e.message ?? 'Bu ses biçimi çözülemedi');
    }
  }
}
