// Whisper'ı platforma göre seçer: telefonda (dart:ffi var) gerçek motor,
// web'de (FlutLab önizlemesi gibi) yalnızca "desteklenmiyor" hatası verir.
export 'whisper_engine_stub.dart' if (dart.library.ffi) 'whisper_engine_native.dart';
