class EngineSegment {
  final int ms;
  final String text;
  const EngineSegment(this.ms, this.text);
}

class EngineResult {
  /// Parça bazlı zaman damgaları (paket vermezse boş).
  final List<EngineSegment> segments;

  /// Tüm metin (segment yoksa buna düşülür).
  final String text;
  const EngineResult(this.segments, this.text);
}
