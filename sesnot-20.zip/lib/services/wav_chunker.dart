import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

class WavInfo {
  final int dataStart;
  final int dataLength;
  const WavInfo(this.dataStart, this.dataLength);
}

class WavChunk {
  final int startMs;
  final int from; // veri içindeki bayt başlangıcı
  final int to;
  const WavChunk(this.startMs, this.from, this.to);
}

/// 16 kHz, mono, 16-bit PCM WAV dosyalarını sessiz noktalardan parçalara böler.
class WavChunker {
  static const int sampleRate = 16000;
  static const int bytesPerSec = sampleRate * 2;
  static const int targetSec = 60;
  static const int _target = targetSec * bytesPerSec;
  static const int _margin = 5 * bytesPerSec;

  /// Beklenen biçimde değilse (mp3, m4a, farklı örnekleme...) null döner.
  /// Kayıt sürerken de çağrılabilir: başlık boyutu eskiyse dosya uzunluğu kullanılır.
  static Future<WavInfo?> readInfo(File f) async {
    final raf = await f.open();
    try {
      final fileLen = await raf.length();
      final head = await raf.read(fileLen < 4096 ? fileLen : 4096);
      if (head.length < 44) return null;
      final bd = ByteData.sublistView(head);
      String tag(int o) => String.fromCharCodes(head.sublist(o, o + 4));
      if (tag(0) != 'RIFF' || tag(8) != 'WAVE') return null;
      var pos = 12;
      var fmtOk = false;
      while (pos + 8 <= head.length) {
        final id = tag(pos);
        final size = bd.getUint32(pos + 4, Endian.little);
        if (id == 'fmt ') {
          final format = bd.getUint16(pos + 8, Endian.little);
          final channels = bd.getUint16(pos + 10, Endian.little);
          final rate = bd.getUint32(pos + 12, Endian.little);
          final bits = bd.getUint16(pos + 22, Endian.little);
          fmtOk = format == 1 && channels == 1 && rate == sampleRate && bits == 16;
        } else if (id == 'data') {
          if (!fmtOk) return null;
          final start = pos + 8;
          final avail = fileLen - start;
          var len = size;
          if (len == 0 || len > avail) len = avail;
          return WavInfo(start, len - (len % 2));
        }
        pos += 8 + size + (size % 2);
      }
      return null;
    } finally {
      await raf.close();
    }
  }

  /// [from] baytından başlayan bir sonraki parçanın bitiş baytı (sessiz noktadan).
  /// Canlı modda (isFinal = false) yeterli ses henüz yoksa null döner.
  static Future<int?> nextCut(
    File f,
    WavInfo info, {
    required int from,
    required bool isFinal,
  }) async {
    final total = info.dataLength;
    if (total <= from) return null;
    if (total - from <= _target + _margin) {
      return isFinal ? total : null;
    }
    final raf = await f.open();
    try {
      return await _quietPoint(raf, info.dataStart, from + _target, _margin, total);
    } finally {
      await raf.close();
    }
  }

  static Future<List<WavChunk>> plan(File f, WavInfo info, {int startAt = 0}) async {
    final chunks = <WavChunk>[];
    var pos = startAt;
    while (true) {
      final end = await nextCut(f, info, from: pos, isFinal: true);
      if (end == null) break;
      chunks.add(WavChunk((pos * 1000) ~/ bytesPerSec, pos, end));
      pos = end;
    }
    return chunks;
  }

  static Future<int> _quietPoint(
    RandomAccessFile raf,
    int dataStart,
    int center,
    int margin,
    int total,
  ) async {
    var from = center - margin;
    from -= from % 2;
    var to = center + margin;
    if (to > total) to = total;
    await raf.setPosition(dataStart + from);
    final bytes = await raf.read(to - from);
    final bd = ByteData.sublistView(bytes);
    const frameBytes = 3200; // 100 ms
    var bestOffset = center - from;
    var bestEnergy = double.infinity;
    for (var o = 0; o + frameBytes <= bytes.length; o += frameBytes) {
      double sum = 0;
      for (var i = o; i < o + frameBytes; i += 2) {
        final v = bd.getInt16(i, Endian.little);
        sum += v * v;
      }
      if (sum < bestEnergy) {
        bestEnergy = sum;
        bestOffset = o + frameBytes ~/ 2;
      }
    }
    var cut = from + bestOffset;
    cut -= cut % 2;
    return cut;
  }

  static Future<Uint8List> readChunk(File src, WavInfo info, WavChunk c) async {
    final raf = await src.open();
    try {
      await raf.setPosition(info.dataStart + c.from);
      return await raf.read(c.to - c.from);
    } finally {
      await raf.close();
    }
  }

  /// Parça büyük ölçüde sessizse true. Temkinli: net bir ses tepesi varsa asla atlamaz.
  /// Gürültü tabanı parçanın kendi 100 ms'lik enerjilerinin %15'lik dilimidir.
  static bool isMostlySilent(Uint8List data) {
    const frameBytes = 3200; // 100 ms
    final bd = ByteData.sublistView(data);
    final energies = <double>[];
    for (var o = 0; o + frameBytes <= data.length; o += frameBytes) {
      double sum = 0;
      var cnt = 0;
      for (var i = o; i < o + frameBytes; i += 16) {
        // her 8. örnek yeterli
        final v = bd.getInt16(i, Endian.little);
        sum += v * v;
        cnt++;
      }
      energies.add(math.sqrt(sum / cnt));
    }
    if (energies.isEmpty) return false;
    final sorted = List<double>.from(energies)..sort();
    final floor = sorted[(sorted.length * 0.15).floor()];
    final threshold = (floor * 3).clamp(100.0, 500.0).toDouble();
    var active = 0;
    for (final e in energies) {
      if (e > threshold) active++;
    }
    final peak = sorted.last;
    return active / energies.length < 0.02 && peak < 800;
  }

  static Future<File> writeChunkFile(Uint8List data, String outPath) async {
    final header = ByteData(44);
    void tag(int o, String s) {
      for (var i = 0; i < 4; i++) {
        header.setUint8(o + i, s.codeUnitAt(i));
      }
    }

    tag(0, 'RIFF');
    header.setUint32(4, 36 + data.length, Endian.little);
    tag(8, 'WAVE');
    tag(12, 'fmt ');
    header.setUint32(16, 16, Endian.little);
    header.setUint16(20, 1, Endian.little);
    header.setUint16(22, 1, Endian.little);
    header.setUint32(24, sampleRate, Endian.little);
    header.setUint32(28, bytesPerSec, Endian.little);
    header.setUint16(32, 2, Endian.little);
    header.setUint16(34, 16, Endian.little);
    tag(36, 'data');
    header.setUint32(40, data.length, Endian.little);

    final out = Uint8List(44 + data.length);
    out.setRange(0, 44, header.buffer.asUint8List());
    out.setRange(44, out.length, data);
    final file = File(outPath);
    await file.writeAsBytes(out, flush: true);
    return file;
  }
}
