import 'package:flutter/services.dart';

/// Android ön plan servisi: ekran kilitlense bile kayıt/çeviri sürsün.
/// Native taraf CI'da eklenir (tools/patch_android_service.py).
class KeepAliveBridge {
  static const _ch = MethodChannel('sesnot/keepalive');

  static Future<void> requestNotificationPermission() async {
    try {
      await _ch.invokeMethod('requestNotificationPermission');
    } catch (_) {}
  }

  /// mode: "recording" | "processing". Servis gerçekten çalışıyorsa true döner.
  static Future<bool> start({required String mode, required String text}) async {
    try {
      await _ch.invokeMethod('start', {'mode': mode, 'text': text});
      await Future.delayed(const Duration(milliseconds: 700));
      return (await _ch.invokeMethod<bool>('isRunning')) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Sistem ses modu: 0 normal, 1 zil çalıyor, 2 arama sürüyor, 3 sesli iletişim (VoIP).
  static Future<int?> audioMode() async {
    try {
      return await _ch.invokeMethod<int>('audioMode');
    } catch (_) {
      return null;
    }
  }

  static Future<void> update(String text) async {
    try {
      await _ch.invokeMethod('update', {'text': text});
    } catch (_) {}
  }

  static Future<void> done(String text) async {
    try {
      await _ch.invokeMethod('done', {'text': text});
    } catch (_) {}
  }

  static Future<void> stop() async {
    try {
      await _ch.invokeMethod('stop');
    } catch (_) {}
  }
}
