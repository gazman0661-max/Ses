import 'dart:io';
import 'wav_chunker.dart';
import 'whisper_engine.dart';

class TimedLine {
  final int ms;
  final String text;
  const TimedLine(this.ms, this.text);
}

/// 16 kHz mono 16-bit WAV: saniye başına bayt sayısı (süre tahmini için).
class WavBytes {
  static const int perSecond = WavChunker.bytesPerSec;
}

String formatStamp(int ms) {
  String two(int n) => n.toString().padLeft(2, '0');
  final s = ms ~/ 1000;
  final h = s ~/ 3600;
  final m = (s % 3600) ~/ 60;
  final sec = s % 60;
  return h > 0 ? '$h:${two(m)}:${two(sec)}' : '${two(m)}:${two(sec)}';
}

String formatTranscript(List<TimedLine> lines, {required bool stamps}) {
  if (stamps) {
    return lines.map((l) => '[${formatStamp(l.ms)}] ${l.text}').join('\n');
  }
  return lines.map((l) => l.text).join(' ');
}

class ChunkStat {
  final int audioMs;
  final int tookMs;
  final bool skipped;
  const ChunkStat(this.audioMs, this.tookMs, this.skipped);
}

/// Bir çeviri işinin ölçümleri (parça başına süre, atlanan sessiz parçalar).
class RunStats {
  final List<ChunkStat> chunks = [];
  int get skipped => chunks.where((c) => c.skipped).length;
  int get audioMs => chunks.fold(0, (a, c) => a + c.audioMs);
}

/// Ses dosyasını telefonda Whisper ile metne çevirir.
/// 16 kHz mono WAV dosyaları ~60 sn'lik parçalara bölünür: ilerleme, iptal, sessiz
/// parçaları atlama ve zaman damgası bu sayede çalışır. Diğer biçimler tek parça çevrilir.
class WhisperService {
  /// Tek bir parçayı çevirir (büyük ölçüde sessizse atlar). Satırlar [lines]'a eklenir.
  static Future<void> transcribeChunk({
    required File file,
    required WavInfo info,
    required WavChunk chunk,
    required String lang,
    required String model,
    required Directory tempDir,
    required List<TimedLine> lines,
    required RunStats stats,
  }) async {
    final audioMs = ((chunk.to - chunk.from) * 1000) ~/ WavChunker.bytesPerSec;
    final data = await WavChunker.readChunk(file, info, chunk);
    if (WavChunker.isMostlySilent(data)) {
      stats.chunks.add(ChunkStat(audioMs, 0, true));
      return;
    }
    final tmp = '${tempDir.path}/chunk_${DateTime.now().microsecondsSinceEpoch}.wav';
    final cf = await WavChunker.writeChunkFile(data, tmp);
    final sw = Stopwatch()..start();
    try {
      lines.addAll(await _transcribeFile(cf.path, lang, model, chunk.startMs, audioMs));
    } finally {
      sw.stop();
      if (await cf.exists()) await cf.delete();
    }
    stats.chunks.add(ChunkStat(audioMs, sw.elapsedMilliseconds, false));
  }

  /// [startAt] bayttan itibaren kalan sesi çevirir (canlı modda kalan kısım için).
  static Future<void> transcribeLong(
    String path, {
    required String lang,
    required String model,
    required List<TimedLine> lines,
    required RunStats stats,
    required Directory tempDir,
    required void Function(int done, int total) onProgress,
    required bool Function() isCancelled,
    int startAt = 0,
    int chunksAlreadyDone = 0,
  }) async {
    final file = File(path);
    final info = await WavChunker.readInfo(file);
    if (info == null || info.dataLength < WavChunker.bytesPerSec * 5) {
      onProgress(0, 1);
      final sw = Stopwatch()..start();
      lines.addAll(await _transcribeFile(path, lang, model, 0, null));
      stats.chunks.add(ChunkStat(0, sw.elapsedMilliseconds, false));
      onProgress(1, 1);
      return;
    }
    final chunks = await WavChunker.plan(file, info, startAt: startAt);
    final total = chunksAlreadyDone + chunks.length;
    onProgress(chunksAlreadyDone, total);
    for (var i = 0; i < chunks.length; i++) {
      if (isCancelled()) return;
      await transcribeChunk(
        file: file,
        info: info,
        chunk: chunks[i],
        lang: lang,
        model: model,
        tempDir: tempDir,
        lines: lines,
        stats: stats,
      );
      onProgress(chunksAlreadyDone + i + 1, total);
    }
  }

  static Future<List<TimedLine>> _transcribeFile(
    String path,
    String lang,
    String model,
    int offsetMs,
    int? chunkMs,
  ) async {
    final r = await whisperTranscribe(path: path, lang: lang, model: model);
    var segs = r.segments;
    // Zaman damgası parçanın süresini aşıyorsa güvenilmez: tüm metne düş.
    if (chunkMs != null && segs.any((s) => s.ms > chunkMs + 2000)) segs = const [];
    if (segs.isNotEmpty) {
      return [for (final s in segs) TimedLine(offsetMs + s.ms, s.text)];
    }
    if (r.text.isEmpty) return const [];
    return [TimedLine(offsetMs, r.text)];
  }
}
