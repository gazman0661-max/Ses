import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/project.dart';

/// Otomatik yedek kapalı: notlar telefondan dışarı çıkmaz.
/// Notlar "projects", Whisper ses kayıtları "recordings" klasöründe durur.
class ProjectStore {
  static Future<Directory> _sub(String name) async {
    final base = await getApplicationSupportDirectory();
    final dir = Directory('${base.path}/$name');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  static Future<Directory> _dir() => _sub('projects');

  static Future<Directory> recordingsDir() => _sub('recordings');

  static Future<List<Project>> list() async {
    final dir = await _dir();
    final items = <Project>[];
    await for (final e in dir.list()) {
      if (e is! File || !e.path.endsWith('.json')) continue;
      try {
        final j = jsonDecode(await e.readAsString()) as Map<String, dynamic>;
        items.add(Project.fromJson(j));
      } catch (_) {
        // bozuk dosyayı atla
      }
    }
    items.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return items;
  }

  /// Hiçbir nota bağlı olmayan (yarım kalmış) kayıt dosyaları, yeniden eskiye.
  static Future<List<File>> orphanRecordings() async {
    final dir = await recordingsDir();
    final used = <String>{};
    for (final p in await list()) {
      final a = p.audioPath;
      if (a != null) used.add(a);
    }
    final out = <File>[];
    await for (final e in dir.list()) {
      if (e is! File) continue;
      final name = e.path.split('/').last;
      if (!name.startsWith('rec_') || !name.endsWith('.wav')) continue;
      if (used.contains(e.path)) continue;
      if (await e.length() < 44 + 32000) continue; // 1 saniyeden kısa
      out.add(e);
    }
    out.sort((a, b) => b.path.compareTo(a.path));
    return out;
  }

  static Future<void> save(Project p) async {
    final dir = await _dir();
    final tmp = File('${dir.path}/${p.id}.tmp');
    await tmp.writeAsString(jsonEncode(p.toJson()), flush: true);
    await tmp.rename('${dir.path}/${p.id}.json');
  }

  static Future<void> delete(String id) async {
    final dir = await _dir();
    final f = File('${dir.path}/$id.json');
    if (!await f.exists()) return;
    try {
      final j = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
      final audio = j['audioPath'] as String?;
      if (audio != null) {
        final af = File(audio);
        if (await af.exists()) await af.delete();
      }
    } catch (_) {}
    await f.delete();
  }

  static Future<void> deleteAll() async {
    for (final dir in [await _dir(), await recordingsDir()]) {
      await for (final e in dir.list()) {
        if (e is File) await e.delete();
      }
    }
  }
}
