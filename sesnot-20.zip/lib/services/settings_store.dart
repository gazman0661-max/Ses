import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

/// Küçük ayarları (seçilen diller gibi) telefonda settings.json içinde tutar.
class SettingsStore {
  static Future<File> _file() async {
    final base = await getApplicationSupportDirectory();
    return File('${base.path}/settings.json');
  }

  static Future<Map<String, dynamic>> _read() async {
    try {
      final f = await _file();
      if (await f.exists()) {
        return jsonDecode(await f.readAsString()) as Map<String, dynamic>;
      }
    } catch (_) {}
    return {};
  }

  static Future<String> getString(String key, String fallback) async {
    final v = (await _read())[key];
    return v is String ? v : fallback;
  }

  static Future<void> setString(String key, String value) async {
    final m = await _read();
    m[key] = value;
    final f = await _file();
    await f.writeAsString(jsonEncode(m), flush: true);
  }
}
