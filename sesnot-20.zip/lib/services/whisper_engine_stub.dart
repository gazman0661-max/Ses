import 'whisper_engine_types.dart';

export 'whisper_engine_types.dart';

/// Web'de Whisper çalışmaz (yerel kütüphane gerekir).
Future<EngineResult> whisperTranscribe({
  required String path,
  required String lang,
  required String model,
}) {
  throw UnsupportedError('Whisper yalnızca Android/iOS uygulamasında çalışır.');
}
