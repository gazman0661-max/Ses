import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models/project.dart';

class PdfService {
  // Turkce karakterler (ğ ş ı İ) icin gomulu font sart.
  // DejaVu Sans uygulamanin icinde gelir, ayrica indirmeye gerek yok.
  static const _regularPath = 'assets/fonts/DejaVuSans.ttf';
  static const _boldPath = 'assets/fonts/DejaVuSans-Bold.ttf';

  static Future<pw.Font> _loadFont(String path) async {
    final data = await rootBundle.load(path);
    return pw.Font.ttf(data);
  }

  static Future<pw.ThemeData> _theme() async {
    try {
      final regular = await _loadFont(_regularPath);
      final bold = await _loadFont(_boldPath);
      return pw.ThemeData.withFont(
        base: regular,
        bold: bold,
        italic: regular,
        boldItalic: bold,
      );
    } catch (_) {
      throw Exception('PDF fontu yüklenemedi ($_regularPath)');
    }
  }

  static List<pw.Widget> _noteWidgets(String title, String body) {
    final paragraphs =
        body.split(RegExp(r'\n+')).where((p) => p.trim().isNotEmpty).toList();
    return [
      pw.Header(level: 0, text: title),
      for (final p in paragraphs)
        pw.Paragraph(text: p, style: pw.TextStyle(fontSize: 12, lineSpacing: 3)),
    ];
  }

  /// Tek not için PDF dosyası (geçici klasörde).
  static Future<File> createPdf({required String title, required String body}) async {
    final theme = await _theme();
    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        theme: theme,
        build: (ctx) => _noteWidgets(title, body),
      ),
    );
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/sesnot_${DateTime.now().millisecondsSinceEpoch}.pdf');
    await file.writeAsBytes(await doc.save());
    return file;
  }

  /// Bütün notlar tek PDF'te, her not yeni sayfadan başlar.
  static Future<Uint8List> notesPdfBytes(List<Project> notes) async {
    final theme = await _theme();
    final doc = pw.Document();
    for (final p in notes) {
      doc.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(40),
          theme: theme,
          build: (ctx) => _noteWidgets(p.title, p.body),
        ),
      );
    }
    return doc.save();
  }
}
