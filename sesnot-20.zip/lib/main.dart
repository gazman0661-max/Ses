import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'theme.dart';

void main() => runApp(const SesNotApp());

class SesNotApp extends StatelessWidget {
  const SesNotApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SesNot',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const HomeScreen(),
    );
  }
}
