import 'package:flutter/material.dart';

const kInk = Color(0xFF0F1720);
const kSurface = Color(0xFF182433);
const kSignal = Color(0xFFFF5A4F);
const kSignalGlow = Color(0x59FF5A4F);
const kText = Color(0xFFE8EEF4);
const kMuted = Color(0xFF8CA0B3);

ThemeData buildTheme() {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: kInk,
    colorScheme: const ColorScheme.dark(
      primary: kSignal,
      onPrimary: Colors.white,
      surface: kSurface,
      onSurface: kText,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: kInk,
      foregroundColor: kText,
      elevation: 0,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: kSurface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    ),
  );
}
