class AppLanguage {
  final String code; // Whisper dil kodu ("auto" = otomatik algıla)
  final String liveLocale; // Android konuşma tanıma dil kimliği
  final String name;
  const AppLanguage(this.code, this.liveLocale, this.name);
}

const List<AppLanguage> kLanguages = [
  AppLanguage('tr', 'tr_TR', 'Türkçe'),
  AppLanguage('en', 'en_US', 'İngilizce'),
  AppLanguage('de', 'de_DE', 'Almanca'),
  AppLanguage('fr', 'fr_FR', 'Fransızca'),
  AppLanguage('es', 'es_ES', 'İspanyolca'),
  AppLanguage('ar', 'ar_SA', 'Arapça'),
  AppLanguage('ru', 'ru_RU', 'Rusça'),
];

/// Sadece Whisper'da: dil otomatik algılanır (paket desteği doğrulanmadı).
const AppLanguage kAutoLanguage =
    AppLanguage('auto', '', 'Otomatik algıla (deneysel)');
