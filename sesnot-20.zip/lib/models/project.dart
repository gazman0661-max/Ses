class Project {
  final String id;
  String title;
  String body;
  final DateTime createdAt;
  DateTime updatedAt;
  String? audioPath;

  Project({
    required this.id,
    required this.title,
    required this.body,
    required this.createdAt,
    required this.updatedAt,
    this.audioPath,
  });

  factory Project.create() {
    final now = DateTime.now();
    return Project(
      id: now.microsecondsSinceEpoch.toString(),
      title: 'Not',
      body: '',
      createdAt: now,
      updatedAt: now,
    );
  }

  factory Project.fromJson(Map<String, dynamic> j) => Project(
        id: j['id'] as String,
        title: j['title'] as String,
        body: j['body'] as String,
        createdAt: DateTime.parse(j['createdAt'] as String),
        updatedAt: DateTime.parse(j['updatedAt'] as String),
        audioPath: j['audioPath'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'audioPath': audioPath,
      };
}
