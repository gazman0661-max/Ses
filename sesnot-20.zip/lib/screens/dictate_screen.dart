import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../models/languages.dart';
import '../models/project.dart';
import '../services/project_store.dart';
import '../services/settings_store.dart';
import '../theme.dart';
import '../widgets/language_picker.dart';
import 'result_screen.dart';

class DictateScreen extends StatefulWidget {
  const DictateScreen({super.key});

  @override
  State<DictateScreen> createState() => _DictateScreenState();
}

class _DictateScreenState extends State<DictateScreen> with WidgetsBindingObserver {
  final SpeechToText _speech = SpeechToText();
  bool _ready = false;
  bool _listening = false; // kullanıcının niyeti: durdurana kadar dinle
  String _committed = '';
  String _partial = '';
  String? _error;
  String? _notice;
  String _localeId = 'tr_TR';
  List<AppLanguage> _options = kLanguages;
  Project? _draft; // kesintide otomatik kaydedilen taslak not

  String get _fullText =>
      [_committed, _partial].where((s) => s.isNotEmpty).join(' ');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _init();
  }

  Future<void> _init() async {
    final ok = await _speech.initialize(
      onStatus: _onStatus,
      onError: (e) {
        if (!mounted) return;
        if (e.errorMsg == 'error_no_match' || e.errorMsg == 'error_speech_timeout') {
          return; // sessizlik hataları normal, oturum yeniden başlatılır
        }
        if (e.permanent && _listening) {
          // örn. arama mikrofonu aldı: dur, yazılanı kaydet
          _interrupt('Dinleme durdu (${e.errorMsg}). Yazılan metin kaydedildi.');
        } else if (!_listening) {
          setState(() => _error = e.errorMsg);
        }
      },
    );
    final saved = await SettingsStore.getString('liveLocale', 'tr_TR');
    var options = kLanguages;
    if (ok) {
      try {
        final ids = (await _speech.locales())
            .map((l) => l.localeId.replaceAll('-', '_'))
            .toSet();
        final filtered =
            kLanguages.where((l) => ids.contains(l.liveLocale)).toList();
        if (filtered.length >= 2) options = filtered;
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() {
      _options = options;
      _localeId = options.any((l) => l.liveLocale == saved)
          ? saved
          : options.first.liveLocale;
      _ready = ok;
      if (!ok) {
        _error = 'Konuşma tanıma açılamadı. Mikrofon iznini ve Google ses servisini kontrol et.';
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Arka planda Android mikrofonu keser: temiz durdur, metni kaybetme.
    if (state == AppLifecycleState.paused && _listening) {
      _interrupt('Uygulama arka plana geçti, dinleme durdu. Yazılan metin kaydedildi.');
    }
  }

  Future<void> _interrupt(String message) async {
    if (!_listening) return;
    setState(() => _listening = false); // önce kapat: 'done' yeniden başlatmasın
    WakelockPlus.disable();
    try {
      await _speech.stop();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _commit();
      _notice = message;
    });
    await _saveDraft();
  }

  Future<void> _saveDraft() async {
    final text = _fullText.trim();
    if (text.isEmpty) return;
    final p = _draft ?? Project.create();
    if (_draft == null) p.title = 'Anlık not';
    p.body = text;
    p.updatedAt = DateTime.now();
    _draft = p;
    await ProjectStore.save(p);
  }

  void _commit() {
    if (_partial.isEmpty) return;
    _committed = _committed.isEmpty ? _partial : '$_committed $_partial';
    _partial = '';
  }

  // Android, sessizlikte oturumu kapatır. Kullanıcı durdurmadıysa yeniden başlat.
  void _onStatus(String status) {
    if (status != 'done' || !mounted) return;
    setState(_commit);
    if (_listening) _startSession();
  }

  Future<void> _startSession() async {
    await Future.delayed(const Duration(milliseconds: 250));
    if (!mounted || !_listening || _speech.isListening) return;
    await _speech.listen(
      localeId: _localeId,
      listenFor: const Duration(minutes: 5),
      pauseFor: const Duration(seconds: 10),
      onResult: (r) {
        if (!mounted) return;
        setState(() {
          _partial = r.recognizedWords;
          if (r.finalResult) _commit();
        });
      },
    );
  }

  void _setLocale(String code) {
    final l = _options.firstWhere((x) => x.code == code, orElse: () => _options.first);
    setState(() => _localeId = l.liveLocale);
    SettingsStore.setString('liveLocale', l.liveLocale);
  }

  Future<void> _toggle() async {
    if (!_ready) return;
    if (_listening) {
      setState(() => _listening = false);
      WakelockPlus.disable();
      await _speech.stop();
      if (mounted) setState(_commit);
    } else {
      WakelockPlus.enable(); // dinlerken ekran kapanmasın
      setState(() {
        _listening = true;
        _error = null;
        _notice = null;
      });
      _startSession();
    }
  }

  Future<void> _finish() async {
    setState(() => _listening = false);
    WakelockPlus.disable();
    await _speech.stop();
    if (!mounted) return;
    setState(_commit);
    final nav = Navigator.of(context);
    if (_draft != null) {
      await _saveDraft();
      if (!mounted) return;
      nav.pushReplacement(
        MaterialPageRoute(builder: (_) => ResultScreen(project: _draft)),
      );
    } else {
      nav.pushReplacement(
        MaterialPageRoute(builder: (_) => ResultScreen(initialText: _fullText)),
      );
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    WakelockPlus.disable();
    _speech.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final text = _fullText;
    final placeholder = !_ready
        ? 'Hazırlanıyor…'
        : (_listening ? 'Dinliyorum…' : 'Başlamak için kırmızı düğmeye dokun.');
    return Scaffold(
      appBar: AppBar(title: const Text('Kayıt')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: SizedBox(
                    width: double.infinity,
                    child: Text(
                      text.isEmpty ? placeholder : text,
                      style: TextStyle(
                        fontSize: 20,
                        height: 1.4,
                        color: text.isEmpty ? kMuted : kText,
                      ),
                    ),
                  ),
                ),
              ),
              if (_notice != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(_notice!, style: const TextStyle(color: kMuted)),
                ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(_error!, style: const TextStyle(color: kSignal)),
                ),
              LanguagePicker(
                value: _options
                    .firstWhere((l) => l.liveLocale == _localeId,
                        orElse: () => _options.first)
                    .code,
                options: _options,
                enabled: !_listening,
                onChanged: _setLocale,
              ),
              const SizedBox(height: 12),
              Semantics(
                button: true,
                label: _listening ? 'Kaydı durdur' : 'Kaydı başlat',
                child: GestureDetector(
                  onTap: _toggle,
                  child: Container(
                    width: 96,
                    height: 96,
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: kSignal),
                    child: Icon(
                      _listening ? Icons.stop_rounded : Icons.mic,
                      size: 44,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: text.isEmpty ? null : _finish,
                  child: const Text('Düzenle ve PDF yap'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
