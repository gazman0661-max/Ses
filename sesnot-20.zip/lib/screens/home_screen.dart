import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/ocr_service.dart';
import '../services/project_store.dart';
import '../services/shared_audio.dart';
import '../services/whisper_service.dart';
import '../theme.dart';
import 'dictate_screen.dart';
import 'history_screen.dart';
import 'result_screen.dart';
import 'settings_screen.dart';
import 'whisper_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _Orphan {
  final File file;
  final int bytes;
  const _Orphan(this.file, this.bytes);
}

class _HomeScreenState extends State<HomeScreen> {
  List<_Orphan> _orphans = [];
  String? _pendingShare; // başka işlem sürerken gelen paylaşım

  @override
  void initState() {
    super.initState();
    _checkOrphans();
    SharedAudio.listen(onShared: _onShared, onError: _shareError);
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadInitialShare());
  }

  @override
  void dispose() {
    SharedAudio.stopListening();
    super.dispose();
  }

  Future<void> _loadInitialShare() async {
    try {
      final p = await SharedAudio.initial();
      if (p != null) await _onShared(p);
    } catch (e) {
      _shareError(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  void _shareError(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('Paylaşılan ses alınamadı: $m')));
  }

  /// "Paylaş → SesNot" ile gelen ses: yazıya dökme ekranını açar. Başka bir ekran
  /// (kayıt/yazıya dökme) açıksa iki işlem çakışmasın diye o bitince açılır.
  Future<void> _onShared(String path) async {
    if (!mounted) return;
    final current = ModalRoute.of(context)?.isCurrent ?? false;
    if (!current) {
      _pendingShare = path;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Paylaşılan ses alındı. Mevcut işlem bitince açılacak.'),
      ));
      return;
    }
    await _open(WhisperScreen(filePath: path));
  }

  void _flushPending() {
    final p = _pendingShare;
    if (p == null || !mounted) return;
    _pendingShare = null;
    _onShared(p);
  }

  Future<void> _checkOrphans() async {
    try {
      final files = await ProjectStore.orphanRecordings();
      final list = <_Orphan>[];
      for (final f in files) {
        list.add(_Orphan(f, await f.length()));
      }
      if (mounted) setState(() => _orphans = list);
    } catch (_) {}
  }

  Future<void> _open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    _checkOrphans();
    _flushPending();
  }

  Future<void> _deleteOrphan(_Orphan o) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Kaydı sil'),
        content: const Text('Yarım kalan kayıt silinecek. Bu işlem geri alınamaz.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Sil'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      if (await o.file.exists()) await o.file.delete();
    } catch (_) {}
    _checkOrphans();
    _flushPending();
  }

  Widget _orphanCard() {
    final o = _orphans.first;
    final secs = o.bytes ~/ WavBytes.perSecond;
    final mb = (o.bytes / 1048576).toStringAsFixed(1);
    final more = _orphans.length > 1 ? ' (+${_orphans.length - 1} daha)' : '';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.restore, color: kText, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Yarım kalan kayıt · ${formatStamp(secs * 1000)} · $mb MB$more',
                  style: const TextStyle(color: kText, fontSize: 14),
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(onPressed: () => _deleteOrphan(o), child: const Text('Sil')),
              const SizedBox(width: 4),
              FilledButton(
                onPressed: () => _open(WhisperScreen(filePath: o.file.path, recovered: true)),
                child: const Text('Yazıya dök'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, c) => SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: c.maxHeight),
              child: IntrinsicHeight(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            tooltip: 'Geçmiş',
                            icon: const Icon(Icons.history, color: kText),
                            onPressed: () => _open(const HistoryScreen()),
                          ),
                          IconButton(
                            tooltip: 'Ayarlar',
                            icon: const Icon(Icons.settings_outlined, color: kText),
                            onPressed: () => _open(const SettingsScreen()),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Konuş,\nyazıya dönsün.',
                        style: TextStyle(
                          fontSize: 34,
                          height: 1.15,
                          fontWeight: FontWeight.w700,
                          color: kText,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Sesi yazıya dök, düzenle, PDF yap.',
                        style: TextStyle(fontSize: 16, color: kMuted),
                      ),
                      if (_orphans.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        _orphanCard(),
                      ],
                      const Spacer(),
                      Center(
                        child: Semantics(
                          button: true,
                          label: 'Kaydı başlat',
                          child: GestureDetector(
                            onTap: () => _open(const DictateScreen()),
                            child: Container(
                              width: 168,
                              height: 168,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: kSignal,
                                boxShadow: [
                                  BoxShadow(color: kSignalGlow, blurRadius: 40, spreadRadius: 6),
                                ],
                              ),
                              child: const Icon(Icons.mic, size: 72, color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      const Center(
                        child: Text('Anlık yazıya dök', style: TextStyle(fontSize: 18, color: kText)),
                      ),
                      const Center(
                        child: Text(
                          'Konuştukça yazılır, kayıt tutulmaz',
                          style: TextStyle(fontSize: 13, color: kMuted),
                        ),
                      ),
                      const Spacer(),
                      _LinkRow(
                        icon: Icons.edit_note,
                        label: 'Metin yapıştır',
                        onTap: () => _open(const ResultScreen()),
                      ),
                      _LinkRow(
                        icon: Icons.document_scanner_outlined,
                        label: 'Fotoğraftan metin',
                        onTap: () => _scanPhoto(context),
                      ),
                      _LinkRow(
                        icon: Icons.graphic_eq,
                        label: 'Kaydet, sonra yazıya dök',
                        hint: 'Whisper',
                        onTap: () => _open(const WhisperScreen()),
                      ),
                      _LinkRow(
                        icon: Icons.audio_file_outlined,
                        label: 'Ses dosyasını yazıya dök',
                        hint: 'Whisper',
                        onTap: () => _pickAudio(context),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(bottom: 4),
                        child: Text(
                          'WhatsApp: sesli mesajı seç → Paylaş → SesNot',
                          style: TextStyle(fontSize: 12, color: kMuted),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _LinkRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? hint;
  final VoidCallback? onTap;

  const _LinkRow({required this.icon, required this.label, this.hint, this.onTap});

  @override
  Widget build(BuildContext context) {
    final color = onTap == null ? kMuted : kText;
    return ListTile(
      contentPadding: EdgeInsets.zero,
      enabled: onTap != null,
      leading: Icon(icon, color: color),
      title: Text(label, style: TextStyle(color: color)),
      trailing: hint == null ? null : Text(hint!, style: const TextStyle(color: kMuted)),
      onTap: onTap,
    );
  }
}

Future<void> _scanPhoto(BuildContext context) async {
  final source = await showModalBottomSheet<ImageSource>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: const Text('Fotoğraf çek'),
            onTap: () => Navigator.pop(ctx, ImageSource.camera),
          ),
          ListTile(
            leading: const Icon(Icons.photo_library_outlined),
            title: const Text('Galeriden seç'),
            onTap: () => Navigator.pop(ctx, ImageSource.gallery),
          ),
        ],
      ),
    ),
  );
  if (source == null || !context.mounted) return;

  final picked = await ImagePicker().pickImage(source: source, imageQuality: 90);
  if (picked == null || !context.mounted) return;

  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) => const Center(child: CircularProgressIndicator()),
  );

  String? text;
  Object? error;
  try {
    text = await OcrService.readText(picked.path);
  } catch (e) {
    error = e;
  }
  if (!context.mounted) return;
  Navigator.of(context).pop();

  final messenger = ScaffoldMessenger.of(context);
  if (error != null) {
    messenger.showSnackBar(SnackBar(content: Text('Okuma hatası: $error')));
    return;
  }
  if (text == null || text.trim().isEmpty) {
    messenger.showSnackBar(
      const SnackBar(content: Text('Metin bulunamadı. Belgeyi daha yakın ve net çek.')),
    );
    return;
  }
  Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => ResultScreen(initialText: text!)),
  );
}

Future<void> _pickAudio(BuildContext context) async {
  final r = await FilePicker.platform.pickFiles(type: FileType.audio);
  final path = r?.files.single.path;
  if (path == null || !context.mounted) return;
  Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => WhisperScreen(filePath: path)),
  );
}
