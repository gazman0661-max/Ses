import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../models/project.dart';
import '../services/file_save_service.dart';
import '../services/pdf_service.dart';
import '../theme.dart';
import '../services/project_store.dart';

class ResultScreen extends StatefulWidget {
  final String initialText;
  final Project? project;
  final String? audioPath;
  const ResultScreen({
    super.key,
    this.initialText = '',
    this.project,
    this.audioPath,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  late final TextEditingController _body =
      TextEditingController(text: widget.project?.body ?? widget.initialText);
  late final TextEditingController _title =
      TextEditingController(text: widget.project?.title ?? 'Not');
  late Project? _project = widget.project;
  late String _savedBody = widget.project?.body ?? '';
  late String _savedTitle = widget.project?.title ?? 'Not';
  Timer? _debounce;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _body.addListener(_onChanged);
    _title.addListener(_onChanged);
  }

  void _onChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 600), _save);
  }

  // Değişiklik varsa notu telefona yazar. Boş yeni not kaydedilmez.
  Future<void> _save() async {
    final body = _body.text;
    final title = _title.text.trim().isEmpty ? 'Not' : _title.text.trim();
    if (_project != null && body == _savedBody && title == _savedTitle) return;
    if (_project == null && body.trim().isEmpty) return;
    final isNew = _project == null;
    final p = _project ?? Project.create();
    if (isNew) p.audioPath = widget.audioPath;
    p.title = title;
    p.body = body;
    p.updatedAt = DateTime.now();
    _project = p;
    _savedBody = body;
    _savedTitle = title;
    await ProjectStore.save(p);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _save();
    _body.dispose();
    _title.dispose();
    super.dispose();
  }

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _sharePdf() async {
    final text = _body.text.trim();
    if (text.isEmpty) {
      _toast('Önce metin yaz ya da konuş.');
      return;
    }
    setState(() => _busy = true);
    try {
      await _save();
      final title = _title.text.trim().isEmpty ? 'Not' : _title.text.trim();
      final file = await PdfService.createPdf(title: title, body: text);
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) _toast('PDF oluşturulamadı: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _savePdf() async {
    final text = _body.text.trim();
    if (text.isEmpty) {
      _toast('Önce metin yaz ya da konuş.');
      return;
    }
    setState(() => _busy = true);
    try {
      await _save();
      final title = _title.text.trim().isEmpty ? 'Not' : _title.text.trim();
      final file = await PdfService.createPdf(title: title, body: text);
      final path = await FileSaveService.save(
        bytes: await file.readAsBytes(),
        fileName: FileSaveService.safeName(title),
        ext: 'pdf',
      );
      if (path != null && mounted) _toast('PDF kaydedildi');
    } catch (e) {
      if (mounted) _toast('PDF kaydedilemedi: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _saveTxt() async {
    final text = _body.text.trim();
    if (text.isEmpty) {
      _toast('Önce metin yaz ya da konuş.');
      return;
    }
    try {
      await _save();
      final title = _title.text.trim().isEmpty ? 'Not' : _title.text.trim();
      final path = await FileSaveService.save(
        bytes: Uint8List.fromList(utf8.encode(text)),
        fileName: FileSaveService.safeName(title),
        ext: 'txt',
      );
      if (path != null && mounted) _toast('Metin kaydedildi');
    } catch (e) {
      if (mounted) _toast('Kaydedilemedi: $e');
    }
  }

  String? get _audio => _project?.audioPath ?? widget.audioPath;

  Future<File?> _audioFile() async {
    final p = _audio;
    if (p == null) return null;
    final f = File(p);
    return await f.exists() ? f : null;
  }

  Future<void> _shareAudio() async {
    final f = await _audioFile();
    if (f == null) {
      if (mounted) _toast('Ses dosyası bulunamadı.');
      return;
    }
    try {
      await Share.shareXFiles([XFile(f.path, mimeType: 'audio/wav')]);
    } catch (e) {
      if (mounted) _toast('Paylaşılamadı: $e');
    }
  }

  // "Farklı kaydet" dosyayı belleğe alır; büyük kayıtlarda paylaşım menüsü daha güvenli.
  Future<void> _saveAudio() async {
    final f = await _audioFile();
    if (f == null) {
      if (mounted) _toast('Ses dosyası bulunamadı.');
      return;
    }
    final size = await f.length();
    if (size > 40 * 1024 * 1024) {
      if (mounted) {
        _toast('Dosya büyük (${(size / 1048576).round()} MB). "Sesi paylaş" ile Dosyalar\'a ya da Drive\'a kaydet.');
      }
      return;
    }
    try {
      final title = _title.text.trim().isEmpty ? 'Not' : _title.text.trim();
      final path = await FileSaveService.save(
        bytes: await f.readAsBytes(),
        fileName: FileSaveService.safeName(title),
        ext: 'wav',
      );
      if (path != null && mounted) _toast('Ses dosyası kaydedildi');
    } catch (e) {
      if (mounted) _toast('Kaydedilemedi: $e');
    }
  }

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: _body.text));
    if (mounted) _toast('Kopyalandı');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Metin')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              TextField(
                controller: _title,
                decoration: const InputDecoration(labelText: 'Başlık'),
              ),
              if (_audio != null) ...[
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Ses kaydı bu notla birlikte saklanıyor, not silinince silinir.',
                      style: TextStyle(fontSize: 12, color: kMuted),
                    ),
                  ),
                ),
                Row(
                  children: [
                    TextButton.icon(
                      onPressed: _shareAudio,
                      icon: const Icon(Icons.ios_share, size: 18),
                      label: const Text('Sesi paylaş'),
                    ),
                    TextButton.icon(
                      onPressed: _saveAudio,
                      icon: const Icon(Icons.download, size: 18),
                      label: const Text('Sesi kaydet'),
                    ),
                  ],
                ),
              ],
              const SizedBox(height: 12),
              Expanded(
                child: TextField(
                  controller: _body,
                  maxLines: null,
                  expands: true,
                  textAlignVertical: TextAlignVertical.top,
                  style: const TextStyle(fontSize: 16, height: 1.4),
                  decoration: const InputDecoration(
                    hintText: 'Metni buraya yaz ya da yapıştır',
                  ),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _busy ? null : _sharePdf,
                  child: Text(_busy ? 'Hazırlanıyor…' : 'PDF olarak paylaş'),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: _busy ? null : _savePdf,
                  child: const Text('PDF\'i cihaza kaydet'),
                ),
              ),
              Row(
                children: [
                  TextButton(onPressed: _copy, child: const Text('Kopyala')),
                  TextButton(onPressed: _saveTxt, child: const Text('Metni kaydet (.txt)')),
                  const Spacer(),
                  const TextButton(onPressed: null, child: Text('Özetle (yakında)')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
