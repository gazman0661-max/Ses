import 'package:flutter/material.dart';
import '../models/project.dart';
import '../services/project_store.dart';
import '../theme.dart';
import 'result_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Project>? _items;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await ProjectStore.list();
    if (mounted) setState(() => _items = list);
  }

  Future<void> _open(Project p) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ResultScreen(project: p)),
    );
    _load();
  }

  Future<void> _delete(Project p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Notu sil'),
        content: Text('“${p.title}” silinecek. Bu işlem geri alınamaz.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Sil'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await ProjectStore.delete(p.id);
      _load();
    }
  }

  String _fmt(DateTime d) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}.${two(d.month)}.${d.year} ${two(d.hour)}:${two(d.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    final items = _items;
    return Scaffold(
      appBar: AppBar(title: const Text('Geçmiş')),
      body: items == null
          ? const Center(child: CircularProgressIndicator())
          : items.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(
                    child: Text(
                      'Henüz not yok.\nBir kayıt başlat ya da metin yapıştır, notların burada durur.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: kMuted, fontSize: 16, height: 1.4),
                    ),
                  ),
                )
              : ListView.separated(
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final p = items[i];
                    final preview = p.body.replaceAll(RegExp(r'\s+'), ' ').trim();
                    return ListTile(
                      title: Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(
                        '${_fmt(p.updatedAt)}\n$preview',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: kMuted),
                      ),
                      isThreeLine: true,
                      trailing: IconButton(
                        tooltip: 'Sil',
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => _delete(p),
                      ),
                      onTap: () => _open(p),
                    );
                  },
                ),
    );
  }
}
