import 'package:flutter/material.dart';
import '../models/languages.dart';
import '../theme.dart';

class LanguagePicker extends StatelessWidget {
  final String value; // seçili dilin code değeri
  final List<AppLanguage> options;
  final ValueChanged<String> onChanged;
  final bool enabled;

  const LanguagePicker({
    super.key,
    required this.value,
    required this.options,
    required this.onChanged,
    this.enabled = true,
  });

  Future<void> _open(BuildContext context) async {
    final picked = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            for (final l in options)
              ListTile(
                title: Text(l.name),
                trailing: l.code == value
                    ? const Icon(Icons.check, color: kSignal)
                    : null,
                onTap: () => Navigator.pop(ctx, l.code),
              ),
          ],
        ),
      ),
    );
    if (picked != null) onChanged(picked);
  }

  @override
  Widget build(BuildContext context) {
    final name =
        options.firstWhere((l) => l.code == value, orElse: () => options.first).name;
    return OutlinedButton.icon(
      onPressed: enabled ? () => _open(context) : null,
      icon: const Icon(Icons.language, size: 18),
      label: Text('Dil: $name'),
    );
  }
}
