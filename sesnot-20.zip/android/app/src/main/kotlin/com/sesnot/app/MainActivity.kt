package com.sesnot.app

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var shareChannel: MethodChannel? = null
    private val ui = Handler(Looper.getMainLooper())

    // Uygulama kapalıyken paylaşımla açıldıysa: Dart hazır olunca teslim edilir.
    private var pendingPath: String? = null
    private var pendingError: String? = null
    private var pendingResult: MethodChannel.Result? = null
    private var initialCopying = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ekran döndürme vb. yeniden oluşturmada aynı paylaşım tekrar işlenmesin.
        if (savedInstanceState == null) handleShare(intent, true)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent, false)
    }

    private fun handleShare(intent: Intent?, initial: Boolean) {
        if (!SharedAudio.isAudioShare(intent)) return
        val uri = SharedAudio.streamUri(intent!!) ?: return
        if (initial) initialCopying = true
        Thread {
            var path: String? = null
            var error: String? = null
            try {
                path = SharedAudio.copyToCache(applicationContext, uri).absolutePath
            } catch (e: Exception) {
                error = e.message ?: "Dosya alınamadı"
            }
            ui.post {
                if (initial) {
                    initialCopying = false
                    val r = pendingResult
                    if (r != null) {
                        pendingResult = null
                        if (path != null) r.success(path) else r.error("share", error, null)
                    } else {
                        pendingPath = path
                        pendingError = error
                    }
                } else {
                    if (path != null) shareChannel?.invokeMethod("shared", path)
                    else shareChannel?.invokeMethod("shareError", error)
                }
            }
        }.start()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val share = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "sesnot/share")
        shareChannel = share
        share.setMethodCallHandler { call, result ->
            when (call.method) {
                "getInitialShare" -> {
                    val p = pendingPath
                    val e = pendingError
                    if (p != null) {
                        pendingPath = null
                        result.success(p)
                    } else if (e != null) {
                        pendingError = null
                        result.error("share", e, null)
                    } else if (initialCopying) {
                        pendingResult = result
                    } else {
                        result.success(null)
                    }
                }
                "convertToWav" -> {
                    val inPath = call.argument<String>("path")
                    if (inPath == null) {
                        result.error("args", "path yok", null)
                    } else {
                        Thread {
                            try {
                                val out = SharedAudio.convertToWav(applicationContext, inPath)
                                ui.post { result.success(out) }
                            } catch (e: Exception) {
                                ui.post {
                                    result.error("decode", e.message ?: "Ses çözülemedi", null)
                                }
                            }
                        }.start()
                    }
                }
                else -> result.notImplemented()
            }
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "sesnot/keepalive")
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "requestNotificationPermission" -> {
                            if (Build.VERSION.SDK_INT >= 33 &&
                                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                                PackageManager.PERMISSION_GRANTED
                            ) {
                                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4301)
                            }
                            result.success(null)
                        }
                        "start" -> {
                            val intent = Intent(this, KeepAliveService::class.java)
                            intent.putExtra("mode", call.argument<String>("mode") ?: "processing")
                            intent.putExtra("text", call.argument<String>("text") ?: "")
                            if (Build.VERSION.SDK_INT >= 26) {
                                startForegroundService(intent)
                            } else {
                                startService(intent)
                            }
                            result.success(true)
                        }
                        "isRunning" -> result.success(KeepAliveService.running)
                        "audioMode" -> {
                            val am = getSystemService(AudioManager::class.java)
                            result.success(am.mode)
                        }
                        "update" -> {
                            if (KeepAliveService.running) {
                                val nm = getSystemService(NotificationManager::class.java)
                                nm.notify(
                                    KeepAliveNotifs.ID,
                                    KeepAliveNotifs.build(
                                        this, KeepAliveNotifs.CHANNEL, "SesNot",
                                        call.argument<String>("text") ?: "", true
                                    )
                                )
                            }
                            result.success(null)
                        }
                        "done" -> {
                            KeepAliveNotifs.ensureChannels(this)
                            val nm = getSystemService(NotificationManager::class.java)
                            nm.notify(
                                KeepAliveNotifs.DONE_ID,
                                KeepAliveNotifs.build(
                                    this, KeepAliveNotifs.DONE_CHANNEL, "SesNot",
                                    call.argument<String>("text") ?: "", false
                                )
                            )
                            result.success(null)
                        }
                        "stop" -> {
                            stopService(Intent(this, KeepAliveService::class.java))
                            result.success(null)
                        }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("keepalive", e.message, null)
                }
            }
    }
}
