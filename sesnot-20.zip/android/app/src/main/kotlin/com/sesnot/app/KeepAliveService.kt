package com.sesnot.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

object KeepAliveNotifs {
    const val CHANNEL = "sesnot_keepalive"
    const val DONE_CHANNEL = "sesnot_done"
    const val ID = 4201
    const val DONE_ID = 4202

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Arka plan işlemleri", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(DONE_CHANNEL, "Çeviri bitti", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun openAppIntent(ctx: Context): PendingIntent? {
        val intent = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: return null
        return PendingIntent.getActivity(
            ctx, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun build(ctx: Context, channel: String, title: String, text: String, ongoing: Boolean): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(ctx, channel)
        } else {
            Notification.Builder(ctx)
        }
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
        openAppIntent(ctx)?.let { builder.setContentIntent(it) }
        return builder.build()
    }
}

class KeepAliveService : Service() {
    companion object {
        @Volatile
        var running = false
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mode = intent?.getStringExtra("mode") ?: "processing"
        val text = intent?.getStringExtra("text") ?: ""
        KeepAliveNotifs.ensureChannels(this)
        val notification = KeepAliveNotifs.build(this, KeepAliveNotifs.CHANNEL, "SesNot", text, true)
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val type = if (mode == "recording") {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                }
                startForeground(KeepAliveNotifs.ID, notification, type)
            } else {
                startForeground(KeepAliveNotifs.ID, notification)
            }
        } catch (e: Exception) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        acquireWakeLock()
        return START_NOT_STICKY
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sesnot:keepalive").apply {
            setReferenceCounted(false)
            acquire(4 * 60 * 60 * 1000L)
        }
    }

    override fun onDestroy() {
        running = false
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
