import re
import sys

manifest = sys.argv[1]
s = open(manifest, encoding="utf-8").read()

perms = """    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.INTERNET"/>
    <queries>
        <intent>
            <action android:name="android.speech.RecognitionService"/>
        </intent>
    </queries>
"""
if "RECORD_AUDIO" not in s:
    s = s.replace("<application", perms + "    <application", 1)

# Android otomatik yedek (Google Drive) kapali: notlar sadece telefonda kalir.
for attr in ("allowBackup", "fullBackupContent", "dataExtractionRules"):
    s = re.sub(r'\s+android:%s="[^"]*"' % attr, "", s)
s = s.replace("<application", '<application android:allowBackup="false"', 1)

# Paylasimla acma: WhatsApp sesli mesaji -> Paylas -> SesNot.
# singleTask: uygulama aciksa ayni pencerede onNewIntent ile yeni ses gelir.
s = s.replace('android:launchMode="singleTop"', 'android:launchMode="singleTask"')
if "android.intent.action.SEND" not in s:
    share = '''            <intent-filter>
                <action android:name="android.intent.action.SEND"/>
                <category android:name="android.intent.category.DEFAULT"/>
                <data android:mimeType="audio/*"/>
                <data android:mimeType="application/ogg"/>
            </intent-filter>
'''
    s = s.replace("</activity>", share + "        </activity>", 1)

open(manifest, "w", encoding="utf-8").write(s)
