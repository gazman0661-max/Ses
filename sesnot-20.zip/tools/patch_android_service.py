import glob
import os
import re
import sys

manifest = sys.argv[1]
main_dir = os.path.dirname(manifest)

cands = glob.glob(os.path.join(main_dir, "kotlin", "**", "MainActivity.kt"), recursive=True)
cands += glob.glob(os.path.join(main_dir, "java", "**", "MainActivity.kt"), recursive=True)
if not cands:
    sys.exit("MainActivity.kt bulunamadi (sablon Kotlin olmayabilir)")
act = cands[0]

m = re.search(r"^package\s+([\w.]+)", open(act, encoding="utf-8").read(), re.M)
if not m:
    sys.exit("MainActivity.kt icinde package satiri yok")
pkg = m.group(1)

tpl_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "android")
targets = (
    ("MainActivity.kt.tpl", act),
    ("KeepAliveService.kt.tpl", os.path.join(os.path.dirname(act), "KeepAliveService.kt")),
    ("AudioBridge.kt.tpl", os.path.join(os.path.dirname(act), "AudioBridge.kt")),
)
for name, out in targets:
    text = open(os.path.join(tpl_dir, name), encoding="utf-8").read().replace("__PKG__", pkg)
    open(out, "w", encoding="utf-8").write(text)

s = open(manifest, encoding="utf-8").read()
perms = [
    "FOREGROUND_SERVICE",
    "FOREGROUND_SERVICE_MICROPHONE",
    "FOREGROUND_SERVICE_DATA_SYNC",
    "POST_NOTIFICATIONS",
    "WAKE_LOCK",
]
add = "".join(
    '    <uses-permission android:name="android.permission.%s"/>\n' % p
    for p in perms
    if "android.permission.%s\"" % p not in s
)
if add:
    s = s.replace("<application", add + "    <application", 1)

if "KeepAliveService" not in s:
    service = (
        '        <service android:name="%s.KeepAliveService" android:exported="false" '
        'android:foregroundServiceType="microphone|dataSync"/>\n' % pkg
    )
    s = s.replace("</application>", service + "    </application>", 1)

open(manifest, "w", encoding="utf-8").write(s)
print("servis eklendi, paket:", pkg)
