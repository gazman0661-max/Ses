import os
import shutil
import sys

# Kullanim: python3 tools/patch_icon.py build_app/android/app/src/main/res
res = sys.argv[1]
src = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon", "res")
if not os.path.isdir(res):
    sys.exit("res klasoru bulunamadi: " + res)
shutil.copytree(src, res, dirs_exist_ok=True)
print("ikon kopyalandi:", res)
