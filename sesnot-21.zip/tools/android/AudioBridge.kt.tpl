package __PKG__

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Paylaşılan sesi (WhatsApp sesli mesajı vb.) uygulama önbelleğine kopyalar ve
 * her türlü sesi (opus/ogg, m4a, mp3, aac, video içindeki ses...) Whisper'ın
 * beklediği 16 kHz mono 16-bit WAV'a çevirir. Ek paket gerektirmez: Android'in
 * kendi MediaExtractor/MediaCodec'ini kullanır.
 */
object SharedAudio {
    private const val SHARED_DIR = "shared"
    private const val CONVERTED_DIR = "converted"
    private const val MAX_AGE_MS = 60L * 60 * 1000
    private const val OUT_RATE = 16000

    fun isAudioShare(intent: Intent?): Boolean {
        if (intent == null || intent.action != Intent.ACTION_SEND) return false
        val type = intent.type ?: return false
        return type.startsWith("audio/") || type == "application/ogg"
    }

    @Suppress("DEPRECATION")
    fun streamUri(intent: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }

    private fun purgeOld(dir: File) {
        val now = System.currentTimeMillis()
        dir.listFiles()?.forEach {
            if (now - it.lastModified() > MAX_AGE_MS) it.deleteRecursively()
        }
    }

    /** İçerik URI'sini önbelleğe kopyalar; özgün dosya adı korunur. */
    fun copyToCache(ctx: Context, uri: Uri): File {
        val base = File(ctx.cacheDir, SHARED_DIR).apply { mkdirs() }
        purgeOld(base)
        var name = "ses"
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrBlank()) name = n
                    }
                }
        } catch (_: Exception) {
        }
        name = name.replace(Regex("[/\\\\:*?\"<>|]"), "_").takeLast(80)
        val sub = File(base, System.currentTimeMillis().toString()).apply { mkdirs() }
        val out = File(sub, name)
        val input = ctx.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Paylaşılan dosya açılamadı")
        input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        if (out.length() == 0L) throw IllegalStateException("Paylaşılan dosya boş")
        return out
    }

    /** [inPath] dosyasını 16 kHz mono WAV'a çevirir, yeni dosyanın yolunu döndürür. */
    fun convertToWav(ctx: Context, inPath: String): String {
        val dir = File(ctx.cacheDir, CONVERTED_DIR).apply { mkdirs() }
        purgeOld(dir)
        val out = File(dir, "conv_${System.currentTimeMillis()}.wav")
        try {
            decodeToWav(inPath, out)
        } catch (e: Exception) {
            out.delete()
            throw e
        }
        return out.absolutePath
    }

    /**
     * APK'nın assets/models klasöründeki Whisper modelini, whisper_ggml'in aradığı yere kopyalar.
     * Dosya zaten tam boyutta varsa dokunmaz; yarım/bozuk dosyanın üstüne yazar.
     * Gömülü model yoksa (eski derleme) false döner, paket kendi indirmesine düşer.
     */
    fun installModel(ctx: Context, name: String, destPath: String): Boolean {
        val expected = expectedModelSize(ctx, name) ?: return false
        val dest = File(destPath)
        if (dest.exists() && dest.length() == expected) return false
        dest.parentFile?.mkdirs()
        if (dest.exists()) dest.delete() // yarım inmiş dosya
        val tmp = File(dest.path + ".part")
        try {
            ctx.assets.open("models/$name").use { input ->
                tmp.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
            }
            if (tmp.length() != expected) {
                throw IllegalStateException("Model kopyası eksik kaldı (yer yetmemiş olabilir)")
            }
            if (!tmp.renameTo(dest)) {
                throw IllegalStateException("Model dosyası yerine konulamadı")
            }
        } catch (e: java.io.FileNotFoundException) {
            tmp.delete()
            return false
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }
        return true
    }

    private fun expectedModelSize(ctx: Context, name: String): Long? {
        try {
            ctx.assets.open("models/sizes.txt").bufferedReader().useLines { lines ->
                for (l in lines) {
                    val p = l.trim().split(" ")
                    if (p.size == 2 && p[0] == name) return p[1].toLongOrNull()
                }
            }
        } catch (e: java.io.FileNotFoundException) {
            return null
        }
        return null
    }

    private fun decodeToWav(inPath: String, out: File) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        var raf: RandomAccessFile? = null
        try {
            extractor.setDataSource(inPath)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("audio/")) {
                    track = i
                    fmt = f
                    break
                }
            }
            if (track < 0 || fmt == null) throw IllegalStateException("Dosyada ses kanalı bulunamadı")
            extractor.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            val dec = MediaCodec.createDecoderByType(mime)
            codec = dec
            dec.configure(fmt, null, null, 0)
            dec.start()

            raf = RandomAccessFile(out, "rw")
            raf.setLength(0)
            raf.write(ByteArray(44)) // başlık sonda yazılır
            val sink = WavSink(raf)

            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE))
                fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 48000
            var channels = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
                fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
            if (channels < 1) channels = 1
            var isFloat = false
            var resampler = Resampler(rate, sink)

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var idle = 0
            while (!outputDone) {
                var progressed = false
                if (!inputDone) {
                    val ii = dec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        progressed = true
                        val buf = dec.getInputBuffer(ii)!!
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val oi = dec.dequeueOutputBuffer(info, 10_000)
                if (oi >= 0) {
                    progressed = true
                    if (info.size > 0) {
                        val ob = dec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.LITTLE_ENDIAN)
                        if (isFloat) {
                            val fb = ob.asFloatBuffer()
                            val frames = fb.remaining() / channels
                            for (f in 0 until frames) {
                                var sum = 0.0
                                for (c in 0 until channels) sum += fb.get()
                                resampler.push(sum / channels * 32767.0)
                            }
                        } else {
                            val sb = ob.asShortBuffer()
                            val frames = sb.remaining() / channels
                            for (f in 0 until frames) {
                                var sum = 0.0
                                for (c in 0 until channels) sum += sb.get()
                                resampler.push(sum / channels)
                            }
                        }
                    }
                    dec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    progressed = true
                    val of = dec.outputFormat
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channels = maxOf(1, of.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                    }
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        val r = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (r != rate) {
                            rate = r
                            resampler = Resampler(rate, sink)
                        }
                    }
                    isFloat = Build.VERSION.SDK_INT >= 24 &&
                        of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                }
                idle = if (progressed) 0 else idle + 1
                if (idle > 1500) throw IllegalStateException("Ses çözme zaman aşımına uğradı")
            }
            sink.finish()
            if (sink.totalBytes == 0L) throw IllegalStateException("Ses çözülemedi (boş çıktı)")
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
            try { raf?.close() } catch (_: Exception) {}
        }
    }

    /** 16-bit mono PCM'i tamponlayıp dosyaya yazar, sonda WAV başlığını doldurur. */
    private class WavSink(private val raf: RandomAccessFile) {
        private val buf = ByteArray(64 * 1024)
        private var n = 0
        var totalBytes = 0L
            private set

        fun write(sample: Int) {
            val v = if (sample > 32767) 32767 else if (sample < -32768) -32768 else sample
            buf[n++] = (v and 0xFF).toByte()
            buf[n++] = ((v shr 8) and 0xFF).toByte()
            totalBytes += 2
            if (n >= buf.size) flush()
        }

        private fun flush() {
            if (n > 0) {
                raf.write(buf, 0, n)
                n = 0
            }
        }

        fun finish() {
            flush()
            val dataLen = totalBytes.toInt()
            val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            b.put("RIFF".toByteArray())
            b.putInt(36 + dataLen)
            b.put("WAVE".toByteArray())
            b.put("fmt ".toByteArray())
            b.putInt(16)
            b.putShort(1) // PCM
            b.putShort(1) // mono
            b.putInt(OUT_RATE)
            b.putInt(OUT_RATE * 2)
            b.putShort(2)
            b.putShort(16)
            b.put("data".toByteArray())
            b.putInt(dataLen)
            raf.seek(0)
            raf.write(b.array())
        }
    }

    /**
     * Alan ortalamalı yeniden örnekleme (kaba bir alçak geçiren filtre görevi görür):
     * her çıkış örneği, kaynaktaki karşılık gelen aralığın ağırlıklı ortalamasıdır.
     * 48 kHz → 16 kHz tam 3'e bölünür; 44.1 kHz gibi oranlar da çalışır.
     */
    private class Resampler(inRate: Int, private val sink: WavSink) {
        private val ratio = inRate.toDouble() / OUT_RATE
        private var idx = 0L
        private var k = 0L
        private var nextBoundary = ratio
        private var acc = 0.0

        fun push(s: Double) {
            var start = idx.toDouble()
            val end = idx + 1.0
            while (start < end - 1e-12) {
                val segEnd = if (nextBoundary < end) nextBoundary else end
                acc += s * (segEnd - start)
                start = segEnd
                if (segEnd >= nextBoundary - 1e-12) {
                    sink.write(Math.round(acc / ratio).toInt())
                    acc = 0.0
                    k++
                    nextBoundary = (k + 1) * ratio
                }
            }
            idx++
        }
    }
}
