import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:record/record.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../models/languages.dart';
import '../services/keep_alive.dart';
import '../services/project_store.dart';
import '../services/settings_store.dart';
import '../services/shared_audio.dart';
import '../services/speed_log.dart';
import '../services/wav_chunker.dart';
import '../services/whisper_service.dart';
import '../theme.dart';
import '../widgets/language_picker.dart';
import 'result_screen.dart';

enum _Stage { idle, recording, processing, error }

class WhisperScreen extends StatefulWidget {
  /// Hazır ses dosyası verilirse kayıt adımı atlanır, dil seçip çeviri başlatılır.
  final String? filePath;

  /// Yarım kalan kayıt kurtarma: çeviriden sonra dosya silinebilir.
  final bool recovered;
  const WhisperScreen({super.key, this.filePath, this.recovered = false});

  @override
  State<WhisperScreen> createState() => _WhisperScreenState();
}

class _WhisperScreenState extends State<WhisperScreen> {
  final AudioRecorder _rec = AudioRecorder();
  _Stage _stage = _Stage.idle;
  Timer? _ticker;
  int _seconds = 0;
  String? _error;
  String? _lastPath;
  bool _lastImported = false;
  bool _deleteAudio = true;
  bool _stamps = true;
  bool _cancel = false;
  bool _paused = false;
  bool _callPaused = false;
  bool _resumeHint = false;
  bool _polling = false;
  int _done = 0;
  int _doneBase = 0;
  int _total = 0;
  int _firstChunkAt = 0;
  String _lang = 'tr';
  String _model = 'small'; // 'base' = hızlı, 'small' = doğru

  // Kayıt sırasında çevirme (deneysel)
  bool _liveMode = false; // ayar
  bool _liveOn = false; // bu kayıtta çalışıyor
  bool _liveBusy = false;
  int _livePos = 0;
  int _liveChunks = 0;
  int _liveMiss = 0;
  String? _liveNote;
  String? _recordPath;

  RunStats _stats = RunStats();
  final List<TimedLine> _lines = [];

  final List<AppLanguage> _options = [...kLanguages, kAutoLanguage];


  @override
  void initState() {
    super.initState();
    _loadPrefs();
    KeepAliveBridge.requestNotificationPermission();
  }

  Future<void> _loadPrefs() async {
    final saved = await SettingsStore.getString('whisperLang', 'tr');
    final stamps = await SettingsStore.getString('whisperStamps', 'true');
    final model = await SettingsStore.getString('whisperModel', 'small');
    final live = await SettingsStore.getString('whisperLive', 'false');
    final known = _options.any((l) => l.code == saved);
    if (!mounted) return;
    setState(() {
      if (known) _lang = saved;
      _stamps = stamps != 'false';
      _model = model == 'base' ? 'base' : 'small';
      _liveMode = live == 'true';
    });
  }

  void _setLang(String code) {
    setState(() => _lang = code);
    SettingsStore.setString('whisperLang', code);
  }

  void _setStamps(bool v) {
    setState(() => _stamps = v);
    SettingsStore.setString('whisperStamps', v ? 'true' : 'false');
  }

  void _setModel(String m) {
    setState(() => _model = m);
    SettingsStore.setString('whisperModel', m);
  }

  void _setLive(bool v) {
    setState(() => _liveMode = v);
    SettingsStore.setString('whisperLive', v ? 'true' : 'false');
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _liveOn = false;
    WakelockPlus.disable();
    KeepAliveBridge.stop();
    _rec.dispose();
    super.dispose();
  }

  String _recordingNotice() =>
      'Kayıt sürüyor · ${_fmt(_seconds)}${_liveChunks > 0 ? ' · $_liveChunks parça yazıya döküldü' : ''}';

  void _startTicker() {
    _ticker?.cancel();
    _seconds = 0;
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (_stage == _Stage.recording) {
        _pollCall();
        if (_paused) return; // duraklatılmışken süre ilerlemez
      }
      setState(() => _seconds++);
      if (_stage == _Stage.recording) {
        if (_liveOn && _seconds % 3 == 0) _liveStep();
        if (_seconds % 30 == 0) KeepAliveBridge.update(_recordingNotice());
      }
    });
  }

  String _fmt(int s) => formatStamp(s * 1000);

  String _fileName(String path) => path.split(RegExp(r'[\\/]')).last;

  String? _eta() {
    final n = _done - _doneBase;
    if (n < 3 || _total == 0) return null;
    final per = (_seconds - _firstChunkAt) / (n - 1);
    final left = (per * (_total - _done)).round();
    return 'Tahmini kalan: ~${_fmt(left)}';
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  // Sistem ses modu: 1 = zil çalıyor, 2 = arama sürüyor. (3 = VoIP, kendi
  // ses ayarımızla karışmasın diye yok sayılır; WhatsApp aramaları algılanmaz.)
  Future<void> _pollCall() async {
    if (_polling) return;
    _polling = true;
    try {
      final mode = await KeepAliveBridge.audioMode();
      if (!mounted || mode == null || _stage != _Stage.recording) return;
      final inCall = mode == 1 || mode == 2;
      if (inCall && !_paused) {
        await _pauseRecording(auto: true);
      } else if (!inCall && _callPaused && !_resumeHint) {
        setState(() => _resumeHint = true);
        KeepAliveBridge.update('Arama bitti. Kayda devam etmek için uygulamayı aç.');
      }
    } finally {
      _polling = false;
    }
  }

  Future<void> _pauseRecording({bool auto = false}) async {
    try {
      await _rec.pause();
      if (!mounted) return;
      setState(() {
        _paused = true;
        _callPaused = auto;
        _resumeHint = false;
      });
      KeepAliveBridge.update(auto
          ? 'Kayıt arama nedeniyle duraklatıldı'
          : 'Kayıt duraklatıldı · ${_fmt(_seconds)}');
    } catch (e) {
      _toast('Duraklatılamadı: $e');
    }
  }

  Future<void> _resumeRecording() async {
    final mode = await KeepAliveBridge.audioMode();
    if (mode == 1 || mode == 2) {
      _toast('Arama sürüyor. Bitince devam edebilirsin.');
      return;
    }
    try {
      await _rec.resume();
      if (!mounted) return;
      setState(() {
        _paused = false;
        _callPaused = false;
        _resumeHint = false;
      });
      KeepAliveBridge.update(_recordingNotice());
    } catch (e) {
      _toast('Devam edilemedi: $e');
    }
  }

  /// Kayıt sürerken biten ~60 sn'lik parçaları çevirir; kayıt bitince bekleme azalır.
  Future<void> _liveStep() async {
    final path = _recordPath;
    if (_liveBusy || !_liveOn || path == null || _stage != _Stage.recording || _paused) {
      return;
    }
    _liveBusy = true;
    try {
      final file = File(path);
      final info = await WavChunker.readInfo(file);
      if (info == null) {
        _liveMiss++;
        if (_liveMiss >= 10) {
          _liveOn = false;
          if (mounted) {
            setState(() => _liveNote =
                'Kayıt dosyası canlı okunamadı. Yazıya dökme kayıt bitince yapılacak.');
          }
        }
        return;
      }
      final cut = await WavChunker.nextCut(file, info, from: _livePos, isFinal: false);
      if (cut == null) return; // henüz yeterli ses yok
      final chunk = WavChunk(
        (_livePos * 1000) ~/ WavChunker.bytesPerSec,
        _livePos,
        cut,
      );
      final temp = await ProjectStore.recordingsDir();
      await WhisperService.transcribeChunk(
        file: file,
        info: info,
        chunk: chunk,
        lang: _lang,
        model: _model,
        tempDir: temp,
        lines: _lines,
        stats: _stats,
      );
      _livePos = cut;
      _liveChunks++;
      if (mounted) setState(() {});
    } catch (e) {
      _liveOn = false;
      if (mounted) {
        setState(() => _liveNote =
            'Canlı yazıya dökme durdu ($e). Kalan kısım kayıt bitince yazıya dökülecek.');
      }
    } finally {
      _liveBusy = false;
    }
  }

  Future<void> _startRecording() async {
    try {
      if (!await _rec.hasPermission()) {
        if (mounted) setState(() => _error = 'Mikrofon izni verilmedi.');
        return;
      }
      final dir = await ProjectStore.recordingsDir();
      final path = '${dir.path}/rec_${DateTime.now().millisecondsSinceEpoch}.wav';
      final svc = await KeepAliveBridge.start(mode: 'recording', text: 'Kayıt sürüyor');
      if (!svc) WakelockPlus.enable();
      _recordPath = path;
      _liveOn = _liveMode;
      _liveBusy = false;
      _livePos = 0;
      _liveChunks = 0;
      _liveMiss = 0;
      _liveNote = null;
      _lines.clear();
      _stats = RunStats();
      await _rec.start(
        const RecordConfig(
          encoder: AudioEncoder.wav,
          sampleRate: 16000,
          numChannels: 1,
        ),
        path: path,
      );
      _startTicker();
      if (mounted) {
        setState(() {
          _stage = _Stage.recording;
          _error = null;
          _paused = false;
          _callPaused = false;
          _resumeHint = false;
        });
      }
    } catch (e) {
      _liveOn = false;
      KeepAliveBridge.stop();
      WakelockPlus.disable();
      if (mounted) setState(() => _error = 'Kayıt başlatılamadı: $e');
    }
  }

  Future<void> _stopAndProcess() async {
    _ticker?.cancel();
    String? path;
    try {
      path = await _rec.stop();
    } catch (_) {}
    if (!mounted) return;
    if (path == null) {
      _liveOn = false;
      KeepAliveBridge.stop();
      WakelockPlus.disable();
      setState(() {
        _stage = _Stage.idle;
        _error = 'Kayıt dosyası oluşturulamadı.';
      });
      return;
    }
    _paused = false;
    _callPaused = false;
    _resumeHint = false;
    await _process(path, imported: false, continueLive: _liveChunks > 0);
  }

  Future<void> _process(
    String path, {
    required bool imported,
    bool continueLive = false,
  }) async {
    _lastPath = path;
    _lastImported = imported;
    if (!mounted) return;
    _cancel = false;
    _liveOn = false;
    // canlı çevirinin sürmekte olan adımı bitsin
    while (_liveBusy) {
      await Future.delayed(const Duration(milliseconds: 200));
    }
    if (!continueLive) {
      _lines.clear();
      _livePos = 0;
      _liveChunks = 0;
      _stats = RunStats();
    }
    _doneBase = continueLive ? _liveChunks : 0;
    _done = _doneBase;
    _total = 0;
    _firstChunkAt = 0;
    setState(() {
      _stage = _Stage.processing;
      _error = null;
    });
    final svc = await KeepAliveBridge.start(mode: 'processing', text: 'Yazıya dökme başlıyor…');
    if (!svc) WakelockPlus.enable();
    _startTicker();
    String? converted; // opus/m4a/mp3 → geçici 16 kHz WAV
    String? convertErr;
    try {
      var workPath = path;
      if (imported && await WavChunker.readInfo(File(path)) == null) {
        KeepAliveBridge.update('Ses hazırlanıyor…');
        try {
          converted = await SharedAudio.toWav(path);
          if (converted != null) workPath = converted;
        } catch (e) {
          // Dönüştürülemezse eski yol denenir (dosya olduğu gibi Whisper'a gider).
          convertErr = e.toString().replaceFirst('Exception: ', '');
        }
      }
      final temp = await ProjectStore.recordingsDir();
      await WhisperService.transcribeLong(
        workPath,
        lang: _lang,
        model: _model,
        lines: _lines,
        stats: _stats,
        tempDir: temp,
        startAt: continueLive ? _livePos : 0,
        chunksAlreadyDone: continueLive ? _liveChunks : 0,
        isCancelled: () => _cancel,
        onProgress: (d, t) {
          _done = d;
          _total = t;
          if (d == _doneBase + 1) _firstChunkAt = _seconds;
          if (mounted) setState(() {});
          KeepAliveBridge.update('Yazıya dökülüyor: $d/$t · ${_fmt(_seconds)}');
        },
      );
      _ticker?.cancel();
      final cancelled = _cancel;
      if (_lines.isEmpty) {
        if (cancelled) {
          if (mounted) {
            setState(() {
              _stage = _Stage.idle;
              _error = 'İptal edildi.';
            });
          }
          return;
        }
        if (_stats.skipped > 0 && _stats.skipped == _stats.chunks.length) {
          throw Exception('Kayıt tamamen sessiz görünüyor');
        }
        throw Exception('Whisper boş sonuç döndürdü');
      }
      final text = formatTranscript(_lines, stamps: _stamps);
      final took = _fmt(_seconds);
      if (!cancelled) {
        await SpeedLog.add(
          model: _model,
          lang: _lang,
          live: continueLive,
          stats: _stats,
          waitSeconds: _seconds,
        );
      }
      String? keep;
      if (!imported) {
        if (_deleteAudio && !cancelled) {
          final f = File(path);
          if (await f.exists()) await f.delete();
        } else {
          keep = path;
        }
      }
      if (!mounted) return;
      if (WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) {
        KeepAliveBridge.done('Yazıya dökme bitti. Notu açmak için dokun.');
      }
      final skipNote =
          _stats.skipped > 0 ? ' · ${_stats.skipped} sessiz parça atlandı' : '';
      _toast(cancelled
          ? 'İptal edildi, yazıya dökülen kısım getirildi'
          : 'Bekleme: $took$skipNote');
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(initialText: text, audioPath: keep),
        ),
      );
    } catch (e) {
      _ticker?.cancel();
      if (mounted) {
        setState(() {
          _stage = _Stage.error;
          _error = 'Yazıya dökme başarısız oldu: $e'
              '${convertErr != null ? '\n(Ses dönüştürme: $convertErr)' : ''}';
        });
      }
    } finally {
      if (converted != null) {
        try {
          final cf = File(converted);
          if (await cf.exists()) await cf.delete();
        } catch (_) {}
      }
      await KeepAliveBridge.stop();
      WakelockPlus.disable();
    }
  }

  void _openPartial() {
    if (_lines.isEmpty) return;
    final keep = _lastImported ? null : _lastPath;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ResultScreen(
          initialText: formatTranscript(_lines, stamps: _stamps),
          audioPath: keep,
        ),
      ),
    );
  }

  Widget _circle(IconData icon, VoidCallback onTap, String label) {
    return Semantics(
      button: true,
      label: label,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 120,
          height: 120,
          decoration: const BoxDecoration(shape: BoxShape.circle, color: kSignal),
          child: Icon(icon, size: 52, color: Colors.white),
        ),
      ),
    );
  }

  Widget _idleView() {
    final file = widget.filePath;
    return ListView(
      children: [
        const SizedBox(height: 8),
        Center(
          child: file != null
              ? Column(
                  children: [
                    const Icon(Icons.audio_file_outlined, size: 64, color: kMuted),
                    const SizedBox(height: 12),
                    Text(
                      widget.recovered ? 'Yarım kalan kayıt' : _fileName(file),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 16, color: kText),
                    ),
                  ],
                )
              : Column(
                  children: [
                    _circle(Icons.mic, _startRecording, 'Kaydı başlat'),
                    const SizedBox(height: 16),
                    const Text('Kaydı başlat',
                        style: TextStyle(fontSize: 20, color: kText)),
                  ],
                ),
        ),
        const SizedBox(height: 20),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'base', icon: Icon(Icons.bolt), label: Text('Hızlı')),
            ButtonSegment(
              value: 'small',
              icon: Icon(Icons.verified_outlined),
              label: Text('Doğru'),
            ),
          ],
          selected: {_model},
          onSelectionChanged: (s) => _setModel(s.first),
        ),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: kSurface,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            _model == 'base'
                ? 'Hızlı (~140 MB): yaklaşık 2-3 kat daha hızlı, telefon daha az ısınır. '
                    'Ama özellikle Türkçede daha çok yanlış ve atlanan kelime olur. '
                    'Kısa, net, sessiz ortamda konuşma için uygun.'
                : 'Doğru (~470 MB): Türkçede belirgin şekilde daha az hata yapar, '
                    'ama daha yavaştır ve telefon ısınabilir. '
                    'Önemli kayıtlar ve uzun metinler için önerilir.',
            style: const TextStyle(fontSize: 13, height: 1.35, color: kMuted),
          ),
        ),
        const SizedBox(height: 12),
        Center(
          child: LanguagePicker(value: _lang, options: _options, onChanged: _setLang),
        ),
        const SizedBox(height: 8),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(_error!, style: const TextStyle(color: kSignal)),
          ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Zaman damgası ekle'),
          subtitle: const Text(
            'Satır başlarına [dk:sn] yazılır',
            style: TextStyle(color: kMuted),
          ),
          value: _stamps,
          onChanged: _setStamps,
        ),
        if (file == null)
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Kayıt sırasında yazıya dök (deneysel)'),
            subtitle: const Text(
              'Bitince bekleme azalır. Telefon ısınabilir, ilk kullanımda model iner.',
              style: TextStyle(color: kMuted),
            ),
            value: _liveMode,
            onChanged: _setLive,
          ),
        if (file == null || widget.recovered)
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Bittikten sonra ses dosyasını sil'),
            value: _deleteAudio,
            onChanged: (v) => setState(() => _deleteAudio = v),
          ),
        if (file != null)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: FilledButton(
              onPressed: () => _process(file, imported: !widget.recovered),
              child: const Text('Yazıya dökmeyi başlat'),
            ),
          ),
        const SizedBox(height: 12),
        const Text(
          'Kayıt ve yazıya dökme bildirimle arka planda sürer. Uygulamayı son uygulamalardan kapatma.',
          style: TextStyle(fontSize: 12, color: kMuted),
        ),
      ],
    );
  }

  Widget _recordingView() {
    final status = _callPaused
        ? 'Arama nedeniyle duraklatıldı'
        : (_paused ? 'Duraklatıldı' : 'Kaydediliyor…');
    return Column(
      children: [
        const Spacer(),
        Text(_fmt(_seconds), style: const TextStyle(fontSize: 48, color: kText)),
        const SizedBox(height: 12),
        Text(status, style: const TextStyle(color: kMuted)),
        if (_liveOn || _liveChunks > 0)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'Canlı: $_liveChunks parça hazır',
              style: const TextStyle(color: kMuted),
            ),
          ),
        if (_liveNote != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              _liveNote!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: kSignal, fontSize: 12),
            ),
          ),
        if (_resumeHint)
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text(
              'Arama bitti. Kayda devam etmek için "Devam et"e dokun.',
              textAlign: TextAlign.center,
              style: TextStyle(color: kSignal),
            ),
          ),
        const Spacer(),
        _circle(Icons.stop_rounded, _stopAndProcess, 'Kaydı bitir ve yazıya dök'),
        const SizedBox(height: 12),
        const Text('Bitir ve yazıya dök', style: TextStyle(fontSize: 18, color: kText)),
        const SizedBox(height: 16),
        TextButton.icon(
          onPressed: _paused ? _resumeRecording : () => _pauseRecording(),
          icon: Icon(_paused ? Icons.play_arrow : Icons.pause),
          label: Text(_paused ? 'Devam et' : 'Duraklat'),
        ),
        const Spacer(),
      ],
    );
  }

  Widget _processingView() {
    final eta = _eta();
    return Column(
      children: [
        const Spacer(),
        LinearProgressIndicator(value: _total > 0 ? _done / _total : null),
        const SizedBox(height: 24),
        Text('Yazıya dökülüyor… ${_fmt(_seconds)}',
            style: const TextStyle(fontSize: 20, color: kText)),
        const SizedBox(height: 8),
        if (_total > 0)
          Text('Parça $_done/$_total', style: const TextStyle(color: kMuted)),
        if (_stats.skipped > 0)
          Text('${_stats.skipped} sessiz parça atlandı',
              style: const TextStyle(color: kMuted)),
        if (eta != null) Text(eta, style: const TextStyle(color: kMuted)),
        const SizedBox(height: 16),
        Text(
          'Whisper modeli uygulamanın içinde gelir; ilk kullanımda hazırlanması birkaç saniye sürebilir. Uzun kayıtlar uzun sürer.',
          textAlign: TextAlign.center,
          style: const TextStyle(color: kMuted, height: 1.4),
        ),
        const SizedBox(height: 16),
        TextButton(
          onPressed: _cancel ? null : () => setState(() => _cancel = true),
          child: Text(_cancel ? 'İptal ediliyor…' : 'İptal et'),
        ),
        const Spacer(),
      ],
    );
  }

  Widget _errorView() {
    return Column(
      children: [
        const Spacer(),
        const Icon(Icons.error_outline, size: 48, color: kSignal),
        const SizedBox(height: 16),
        Text(_error ?? 'Bir hata oluştu',
            textAlign: TextAlign.center, style: const TextStyle(color: kText)),
        const SizedBox(height: 24),
        FilledButton(
          onPressed: _lastPath == null
              ? null
              : () => _process(_lastPath!, imported: _lastImported),
          child: const Text('Tekrar dene'),
        ),
        if (_lines.isNotEmpty)
          TextButton(
            onPressed: _openPartial,
            child: const Text('Yazıya dökülen kısmı aç'),
          ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        const Spacer(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final busy = _stage == _Stage.recording || _stage == _Stage.processing;
    final Widget content;
    switch (_stage) {
      case _Stage.idle:
        content = _idleView();
        break;
      case _Stage.recording:
        content = _recordingView();
        break;
      case _Stage.processing:
        content = _processingView();
        break;
      case _Stage.error:
        content = _errorView();
        break;
    }
    return PopScope(
      canPop: !busy,
      child: Scaffold(
        appBar: AppBar(title: const Text('Kaydet ve yazıya dök')),
        body: SafeArea(
          child: Padding(padding: const EdgeInsets.all(24), child: content),
        ),
      ),
    );
  }
}
