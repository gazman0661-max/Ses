import 'package:flutter/material.dart';
import '../services/notes_export_service.dart';
import '../services/project_store.dart';
import '../services/speed_log.dart';
import '../theme.dart';

const _privacyText =
    'Taslak metin. Yayından önce gerçek gizlilik politikanla değiştir.\n\n'
    'Ses (Anlık): Android\'in ses servisiyle yapılır. Servis, cihazına ve ayarlarına göre sesi Google\'a gönderebilir. Kayıt tutulmaz.\n\n'
    'Ses (Whisper): Kayıt ve yazıya dökme telefonunda yapılır. Model dosyası uygulamanın içinde gelir, internet gerekmez.\n\n'
    'Fotoğraf: Fotoğraftan metin okuma cihazda yapılır.\n\n'
    'Notlar: Sadece telefonunda saklanır, otomatik yedeklenmez. İstersen "Tüm notları dışa aktar" ile PDF veya metin dosyası olarak alabilirsin.';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _info(BuildContext context, String title, String text) {
    return showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(child: Text(text)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Tamam')),
        ],
      ),
    );
  }

  Future<void> _exportSheet(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);

    Future<void> go(ExportFormat format, bool share) async {
      try {
        final r = await NotesExportService.run(format: format, share: share);
        if (r == null) {
          messenger.showSnackBar(
            const SnackBar(content: Text('Dışa aktarılacak not yok')),
          );
        } else if (r && !share) {
          messenger.showSnackBar(const SnackBar(content: Text('Kaydedildi')));
        }
      } catch (e) {
        messenger.showSnackBar(
          SnackBar(content: Text('Dışa aktarma başarısız oldu: $e')),
        );
      }
    }

    Widget option(BuildContext ctx, IconData icon, String title, String sub,
        ExportFormat f, bool share) {
      return ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(sub),
        onTap: () {
          Navigator.pop(ctx);
          go(f, share);
        },
      );
    }

    await showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            option(ctx, Icons.picture_as_pdf_outlined, 'PDF olarak kaydet',
                'Klasörü ve dosya adını sen seç', ExportFormat.pdf, false),
            option(ctx, Icons.ios_share, 'PDF olarak paylaş',
                'WhatsApp, e-posta, Drive…', ExportFormat.pdf, true),
            option(ctx, Icons.description_outlined, 'Metin (.txt) olarak kaydet',
                'Klasörü ve dosya adını sen seç', ExportFormat.txt, false),
            option(ctx, Icons.ios_share, 'Metin (.txt) olarak paylaş',
                'WhatsApp, e-posta, Drive…', ExportFormat.txt, true),
          ],
        ),
      ),
    );
  }

  Future<void> _showSpeedLog(BuildContext context) async {
    final entries = await SpeedLog.load();
    if (!context.mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hız ölçümleri'),
        content: SingleChildScrollView(
          child: Text(
            entries.isEmpty
                ? 'Henüz ölçüm yok. Bir işlem bitince burada görünür.'
                : entries.map(SpeedLog.describe).join('\n\n'),
          ),
        ),
        actions: [
          if (entries.isNotEmpty)
            TextButton(
              onPressed: () async {
                await SpeedLog.clear();
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('Temizle'),
            ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Tamam')),
        ],
      ),
    );
  }

  Future<void> _deleteAll(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tüm notları sil'),
        content: const Text('Telefondaki bütün notlar silinecek. Bu işlem geri alınamaz.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Tümünü sil'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await ProjectStore.deleteAll();
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tüm notlar silindi')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.privacy_tip_outlined),
            title: const Text('Gizlilik özeti'),
            onTap: () => _info(context, 'Gizlilik özeti', _privacyText),
          ),
          ListTile(
            leading: const Icon(Icons.file_download_outlined),
            title: const Text('Tüm notları dışa aktar'),
            subtitle: const Text('PDF veya metin dosyası olarak'),
            onTap: () => _exportSheet(context),
          ),
          ListTile(
            leading: const Icon(Icons.speed_outlined),
            title: const Text('Hız ölçümleri'),
            subtitle: const Text('Son işlemlerin süreleri'),
            onTap: () => _showSpeedLog(context),
          ),
          ListTile(
            leading: const Icon(Icons.delete_forever_outlined, color: kSignal),
            title: const Text('Tüm notları sil', style: TextStyle(color: kSignal)),
            onTap: () => _deleteAll(context),
          ),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('Hakkında'),
            subtitle: Text('SesNot 0.1.0', style: TextStyle(color: kMuted)),
          ),
        ],
      ),
    );
  }
}
